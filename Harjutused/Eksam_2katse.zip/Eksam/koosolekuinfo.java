package Harjutused.Eksam;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by anni-bessie on 30.01.17.
 */
public class koosolekuinfo {
    int tunde;
    ArrayList <String[]> teemad = new ArrayList();


    public void lisaTeema(String tootaja, String lisatudteema) {
        String [] rida = new String [2];
        rida [0] = tootaja;
        rida [1] = lisatudteema;

        teemad.add (rida);

    }

    public void prindikoikteemad() {
        for (int i = 0; i < teemad.size() ; i++) {
            System.out.println("Käesoleval nädalal oli planeeris läbida järgnevad teemad: " + Arrays.toString(teemad.get(i)));
        }

        System.out.println();
    }

    public void planeeritudaeg() {
        for (int i = 0; i < teemad.size(); i++){
            tunde ++;
        }
        System.out.println("Koosoleku teemadeks tuleks teemade arutamiseks planeerida: " + tunde + " tundi.");
    }


    public void labitudTeema(String eemaldateema) {
        for (int i = 0; i < teemad.size(); i++) {
            if (teemad.get(i) [1].equals(eemaldateema)){
                teemad.remove(i);
            }
        }
    }

    public void labimataTeemad() {
        for (int i = 0; i < teemad.size(); i++) {
            System.out.println("Läbimata teemad käesolevad nädalal: " + Arrays.toString(teemad.get(i)));
        }
    }

    public void motivatsioonteemadele (){
        if (teemad.size() > 1){
            System.out.println("Tuleks teha veidi produktiivsemaid koosolekuid, et jõuaksite rohkem teemasid läbida!");
        } else {
            System.out.println("Tublid! Olete ilusti teemadega graafikus!");
        }
    }


    public void ajakulu() {
        for (int i = 0; i < teemad.size(); i++){
            tunde --;
        }
        if (tunde < 1) {
            System.out.println("Isegi ajaliselt :)");
        }
        else {
        System.out.println("Olete hetkel koosolekugraafikust maas " + tunde + " tundi.");
        }
    }

}
