package Harjutused.Eksam;

/**
 * Created by anni-bessie on 30.01.17.
 */
public class Koosolek {
    public static void main (String [] args){

        koosolekuinfo koosolek = new koosolekuinfo();

        koosolek.lisaTeema("Kristel", "Juhatuse koosseis");
        koosolek.lisaTeema("Raivo", "Turundusplaan");
        koosolek.lisaTeema("Eneli", "Müügiaruanded");
        koosolek.lisaTeema("Kristel", "Personalikulud");
        koosolek.lisaTeema("Maris", "Koristus");
        koosolek.lisaTeema("Teet", "Majanduskava");
        koosolek.prindikoikteemad();
        koosolek.planeeritudaeg();


        koosolek.labitudTeema ("Turundusplaan");
        koosolek.labitudTeema("Personalikulud");
        koosolek.labitudTeema("Koristus");

        koosolek.labimataTeemad();
        koosolek.motivatsioonteemadele();

        koosolek.ajakulu();

    }
}
